#include <gtest/gtest.h>

#include <valijson/schema.hpp>

using valijson::Schema;

class TestDereferenceCallback : public ::testing::Test
{

};

TEST_F(TestDereferenceCallback, Basics)
{

}
